import 'dart:ui';

const greenColor = Color(0xff21CE99);
const greyColor = Color(0xFFA0A2A4);
const blackColor = Color(0xFF171A1E);
const redColor = Color(0xFFCF6679);
